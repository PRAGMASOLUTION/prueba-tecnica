# EBC · Examen de contabilidad

Aplicación web para presentar un examen de cinco preguntas, guardar un único intento activo por estudiante y consultar su resultado. Cada respuesta correcta vale 2 puntos; la calificación máxima es 10 y se aprueba con 6.

El proyecto incluye una interfaz web, una API HTTP organizada con MVC, una base de datos Supabase, un panel privado para el maestro y un acceso LTI 1.1 desde Moodle.

## Funcionalidades

- Entrada del estudiante con validación básica: el correo debe incluir `@` y no tener espacios.
- Orden aleatorio de preguntas, guardado junto con el intento.
- Guardado automático de respuestas y calificación calculada en el backend.
- Bloqueo permanente del intento si la página deja de estar visible durante el examen.
- Resultado final con respuestas correctas e incorrectas, aciertos, calificación sobre 10 y estado de aprobado o reprobado.
- Un intento activo por correo. El maestro puede reactivarlo después de escribir un motivo; el resultado anterior y la autorización se guardan en el historial.
- Panel del maestro en `/panel-maestro`.
- Página pública de resultados en `/resultados`, en modo de solo lectura.
- Inicio de sesión desde Moodle mediante LTI 1.1.

## Tecnologías

- Node.js 24.11.1 y Express 5 para el servidor y la API.
- HTML, CSS y JavaScript sin framework para la interfaz.
- Supabase PostgreSQL para estudiantes, preguntas e intentos.
- Docker y Docker Compose para empaquetar y ejecutar el servidor.
- LTI 1.1 con firma OAuth 1.0 HMAC-SHA1.

## Requisitos

- Node.js 24.11.1 (npm 11.6.1).
- Un proyecto de Supabase con acceso a SQL Editor.
- Docker Desktop solo si se ejecuta con Docker Compose.
- Un dominio HTTPS público y acceso para registrar una herramienta externa en Moodle si se usa LTI.

## Base de datos y variables de entorno

1. En Supabase, abre **SQL Editor** y ejecuta el contenido completo de `database.sql`. El script crea las tablas y preguntas, carga estudiantes de muestra y aplica la migración de calificaciones e historial de reactivaciones.
2. En la carpeta del proyecto, crea `.env` a partir de `.env.example` si todavía no existe:

   ```powershell
   if (!(Test-Path .env)) { Copy-Item .env.example .env }
   ```

3. Configura las variables de `.env`:

   | Variable | Uso |
   |---|---|
   | `PORT` | Puerto del servidor; por defecto `3000`. |
   | `NODE_ENV` | Usa `production` en el hosting con HTTPS. |
   | `SUPABASE_URL` | URL del proyecto Supabase. |
   | `SUPABASE_SECRET_KEY` | Clave secreta usada solo por el backend. |
   | `SESSION_SECRET` | Secreto para firmar las sesiones; mínimo 32 caracteres. |
   | `EVALUATOR_EMAIL` | Correo de acceso al panel privado del maestro. |
   | `EVALUATOR_PASSWORD` | Contraseña del panel privado del maestro. |
   | `LTI_CONSUMER_KEY` | Clave compartida con Moodle para LTI 1.1. |
   | `LTI_CONSUMER_SECRET` | Secreto compartido con Moodle para LTI 1.1. |
   | `LTI_PUBLIC_URL` | URL HTTPS exacta terminada en `/lti/launch`. |
   | `LTI_ALLOWED_ORIGIN` | Origen HTTPS de Moodle, necesario para mostrar la herramienta dentro de un marco. |

**No publiques `.env` ni la clave secreta de Supabase en GitHub.** El archivo está excluido mediante `.gitignore`. En un hosting, configura esas variables en el panel del proveedor.

## Instalación e inicio local

Desde PowerShell, en la carpeta del proyecto:

```powershell
npm install
npm run dev
```

Abre `http://localhost:3000`. Para iniciar sin el modo de desarrollo, usa:

```powershell
npm start
```

El proyecto requiere Node.js 24.11.1; `npm install` instala las dependencias indicadas en `package.json`.

### Docker Compose

Con Docker Desktop instalado y el archivo `.env` configurado:

```powershell
docker compose up --build
```

La aplicación queda en `http://localhost:3000`. Para detenerla:

```powershell
docker compose down
```

Compose ejecuta el servidor web; la base de datos permanece alojada en Supabase.

## Accesos de demostración

- **Estudiantes:** cualquier correo que incluya `@` y no tenga espacios. Hay registros de muestra: `ana.demo@example.com`, `luis.demo@example.com` y `maria.demo@example.com`.
- **Panel del maestro:** `http://localhost:3000/panel-maestro`. Usa `EVALUATOR_EMAIL` y `EVALUATOR_PASSWORD` de `.env` (en la configuración de demostración: `maestro@demo.com` y `maestrodemo2026`). El panel no aparece enlazado desde el examen.
- **Resultados públicos:** `http://localhost:3000/resultados`. No requiere contraseña; cualquier persona con acceso a la URL puede ver correos, aciertos, calificaciones, estados y fechas.

En ejecución local, `localhost` solo es accesible desde la computadora que ejecuta la aplicación. Para compartir una URL por internet, despliega el servidor en un hosting con Node.js y HTTPS y configura allí las variables de entorno.

## API

| Método | Ruta | Descripción |
|---|---|---|
| `POST` | `/api/session` | Registra o reconoce al estudiante y prepara su intento. |
| `GET` | `/api/exam` | Devuelve el examen o el resultado final del estudiante con sesión. |
| `POST` | `/api/answers` | Guarda una respuesta del intento activo. |
| `POST` | `/api/submit` | Cierra el intento y calcula la calificación. |
| `POST` | `/api/lock` | Bloquea el intento por cambio de visibilidad. |
| `POST` | `/api/evaluator/login` | Inicia sesión del maestro. |
| `GET` | `/api/evaluator/attempts` | Devuelve intentos e historial para el panel del maestro. |
| `POST` | `/api/evaluator/attempts/:studentId/reactivate` | Reactiva el intento si incluye un motivo válido. |
| `GET` | `/api/shared-results` | Devuelve los datos resumidos que muestra la página pública. |
| `GET` | `/api/health` | Informa si el backend puede consultar Supabase. |
| `POST` | `/lti/launch` | Recibe y valida el lanzamiento LTI 1.1 desde Moodle. |

La API pública de resultados devuelve solo correo, intento, aciertos, calificación, estado y fecha. La clave de Supabase permanece en el backend.

## Arquitectura y estructura

El servidor Express entrega los archivos estáticos del frontend y expone la API. La estructura MVC separa las rutas, la lógica de control y las consultas a Supabase:

```text
public/
  index.html, app.js, styles.css       Pantalla del estudiante
  evaluator.html, evaluator.js         Panel privado del maestro
  results.html, results.js             Consulta pública de resultados
src/
  app.js                                Configuración de Express y middleware
  server.js                             Inicio del servidor Node.js
  routes/                               Rutas del examen, panel, resultados y LTI
  controllers/                          Flujos de la aplicación
  models/                               Consultas a Supabase
  middleware/                           Protección de sesión
  config/                               Cliente Supabase y sesiones firmadas
database.sql                            Esquema, migración y datos de muestra
Dockerfile                              Imagen de Node.js
docker-compose.yml                      Servicio web local
```

El backend guarda la respuesta correcta en Supabase y no la envía al navegador antes de cerrar el intento. Las preguntas se mezclan al iniciar cada intento y su orden se conserva. Al reactivar, se archiva el intento anterior, se guarda el motivo y se crea un nuevo orden de preguntas.

## Configuración de Moodle LTI 1.1

La aplicación debe estar desplegada bajo HTTPS antes de registrar la herramienta:

1. En Moodle, agrega una actividad **Herramienta externa**.
2. Usa como URL de lanzamiento `https://TU-DOMINIO/lti/launch`.
3. Introduce en Moodle los mismos valores de `LTI_CONSUMER_KEY` y `LTI_CONSUMER_SECRET` configurados en el hosting.
4. Configura `LTI_PUBLIC_URL` con la URL exacta de lanzamiento y `LTI_ALLOWED_ORIGIN` con el origen de Moodle, por ejemplo `https://campus.ejemplo.com`.
5. Si Moodle lo permite, habilita el envío del correo del estudiante. Si no lo envía, la aplicación crea una identidad estable a partir del identificador LTI.

El endpoint valida la firma, la fecha y el nonce del lanzamiento, y crea una sesión para que el estudiante entre sin escribir su correo. Para una prueba real, se necesita registrar y abrir la actividad desde una instancia Moodle.

## Supuestos, dudas y limitaciones

- Se asumió un examen fijo de cinco preguntas; cada acierto vale 2 puntos y la calificación mínima aprobatoria es 6/10.
- El correo solo se valida para comprobar que incluye `@` y no tiene espacios. No se verifica que exista ni que pertenezca a quien lo escribe.
- El correo es el identificador de acceso para la demo. Quien conozca el correo de otra persona podría consultar su intento.
- La ruta `/resultados` es pública y muestra datos personales de la demo. No debe usarse con información real sin agregar control de acceso.
- El navegador puede detectar que la página pierde visibilidad y bloquear el intento, pero no puede impedir el uso de otro dispositivo o garantizar que nadie consulte herramientas externas.
- No se implementaron temporizador, supervisión por cámara, recuperación de identidad ni envío de calificaciones a Moodle.
- La base de datos se administra en Supabase; Docker Compose solo ejecuta la aplicación.

## Mejoras posibles con más tiempo

- Migrar la conexión Moodle a LTI 1.3 con OpenID Connect.
- Agregar pruebas automatizadas para la API, la calificación, la reactivación y el lanzamiento LTI.
- Añadir exportación CSV e historial más detallado al panel del maestro.
- Reemplazar el acceso compartido del maestro por cuentas individuales y roles.
- Proteger la consulta pública de resultados con autenticación o un enlace temporal y reducir los datos personales expuestos.
- Separar las migraciones de base de datos en archivos versionados y agregar un entorno de staging.

## Uso de herramientas de IA

Se utilizaron herramientas de IA como apoyo para planear la arquitectura, redactar partes del código y preparar esta documentación. El código debe revisarse antes de emplearse fuera de esta demostración.
