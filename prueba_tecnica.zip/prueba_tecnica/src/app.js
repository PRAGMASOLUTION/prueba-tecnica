require('dotenv').config();
const path = require('node:path');
const express = require('express');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const supabase = require('./config/supabase');
const examRoutes = require('./routes/examRoutes');
const evaluatorRoutes = require('./routes/evaluatorRoutes');
const ltiRoutes = require('./routes/ltiRoutes');
const sharedResultsRoutes = require('./routes/sharedResultsRoutes');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
const allowedLtiOrigin = process.env.LTI_ALLOWED_ORIGIN;
app.use(helmet({ frameguard: false, contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], styleSrc: ["'self'"], scriptSrc: ["'self'"], imgSrc: ["'self'", 'data:'],
  connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'self'", ...(allowedLtiOrigin ? [allowedLtiOrigin] : [])],
} } }));
app.use(express.json({ limit: '20kb', type: 'application/json' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: 'draft-8', legacyHeaders: false,
  message: { error: 'Demasiadas solicitudes. Espera unos minutos e inténtalo de nuevo.' } }));

app.get('/api/health', async (_req, res) => {
  const { error } = await supabase.from('exam_questions').select('id').limit(1);
  if (error) return res.status(503).json({ status: 'error', message: 'No fue posible consultar Supabase.' });
  return res.json({ status: 'ok', database: 'connected' });
});
app.use('/api', examRoutes);
app.use('/api/evaluator', evaluatorRoutes);
app.use('/api/shared-results', sharedResultsRoutes);
app.use('/lti', ltiRoutes);
app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'] }));
app.get('/evaluador', (_req, res) => res.redirect(302, '/panel-maestro'));
app.get('/panel-maestro', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'evaluator.html')));
app.get('/resultados', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'results.html')));
app.get('/{*splat}', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.use((error, _req, res, _next) => {
  console.error('Request failed:', error.message);
  const status = Number.isInteger(error.status) ? error.status : 500;
  return res.status(status).json({ error: status < 500 ? error.message : 'Ocurrió un error al procesar la solicitud.' });
});

module.exports = app;
