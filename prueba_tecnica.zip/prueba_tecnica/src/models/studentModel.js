const supabase = require('../config/supabase');

async function findOrCreateByEmail(email) {
  const { data: student, error: lookupError } = await supabase.from('students')
    .select('id, email').eq('email', email).maybeSingle();
  if (lookupError) throw lookupError;
  if (student) return student;

  const { data, error } = await supabase.from('students')
    .insert({ email }).select('id, email').single();
  if (error?.code === '23505') {
    const { data: existing, error: retryError } = await supabase.from('students')
      .select('id, email').eq('email', email).single();
    if (retryError) throw retryError;
    return existing;
  }
  if (error) throw error;
  return data;
}

async function findOrCreateByLti(userId, email) {
  const { data: linked, error: lookupError } = await supabase.from('students')
    .select('id, email, lti_user_id').eq('lti_user_id', userId).maybeSingle();
  if (lookupError) throw lookupError;
  if (linked) return linked;

  const { data: byEmail, error: emailError } = await supabase.from('students')
    .select('id, email, lti_user_id').eq('email', email).maybeSingle();
  if (emailError) throw emailError;
  if (byEmail) {
    if (byEmail.lti_user_id && byEmail.lti_user_id !== userId) throw new Error('El correo ya está asociado a otro usuario de Moodle.');
    const { data, error } = await supabase.from('students').update({ lti_user_id: userId }).eq('id', byEmail.id).select('id, email, lti_user_id').single();
    if (error) throw error;
    return data;
  }

  const { data, error } = await supabase.from('students').insert({ email, lti_user_id: userId }).select('id, email, lti_user_id').single();
  if (error?.code === '23505') {
    const { data: retry, error: retryError } = await supabase.from('students').select('id, email, lti_user_id').eq('lti_user_id', userId).single();
    if (retryError) throw retryError;
    return retry;
  }
  if (error) throw error;
  return data;
}

module.exports = { findOrCreateByEmail, findOrCreateByLti };
