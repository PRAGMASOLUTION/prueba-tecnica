const supabase = require('../config/supabase');

async function listActiveQuestions() {
  const { data, error } = await supabase.from('exam_questions')
    .select('id, question_text, options, correct_option').eq('active', true).order('id');
  if (error) throw error;
  return data || [];
}

module.exports = { listActiveQuestions };
