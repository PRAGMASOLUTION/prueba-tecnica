const supabase = require('../config/supabase');

async function findByStudentId(studentId) {
  const { data, error } = await supabase.from('exam_attempts').select('*').eq('student_id', studentId).maybeSingle();
  if (error) throw error;
  return data;
}

async function create(studentId, questionOrder) {
  const { data, error } = await supabase.from('exam_attempts')
    .insert({ student_id: studentId, question_order: questionOrder }).select('*').single();
  if (error?.code === '23505') return findByStudentId(studentId);
  if (error) throw error;
  return data;
}

async function saveAnswer(attemptId, answers) {
  const { data, error } = await supabase.from('exam_attempts').update({ answers })
    .eq('id', attemptId).eq('status', 'in_progress').select('*').maybeSingle();
  if (error) throw error;
  return data;
}

async function finish(attemptId, status, correctCount, score, passed) {
  const timestamp = new Date().toISOString();
  const fields = status === 'locked'
    ? { status, correct_count: correctCount, score, passed, locked_at: timestamp }
    : { status, correct_count: correctCount, score, passed, submitted_at: timestamp };
  const { data, error } = await supabase.from('exam_attempts').update(fields)
    .eq('id', attemptId).eq('status', 'in_progress').select('*').maybeSingle();
  if (error) throw error;
  if (data) return data;
  const existing = await supabase.from('exam_attempts').select('*').eq('id', attemptId).single();
  if (existing.error) throw existing.error;
  return existing.data;
}

async function listAllWithStudents() {
  const { data: attempts, error: attemptsError } = await supabase.from('exam_attempts')
    .select('id, student_id, status, score, answers, question_order, started_at, submitted_at, locked_at')
    .order('created_at', { ascending: false });
  if (attemptsError) throw attemptsError;
  if (!attempts?.length) return [];
  const studentIds = [...new Set(attempts.map((attempt) => attempt.student_id))];
  const { data: students, error: studentsError } = await supabase.from('students').select('id, email').in('id', studentIds);
  if (studentsError) throw studentsError;
  const attemptIds = attempts.map((attempt) => attempt.id);
  const { data: history, error: historyError } = await supabase.from('exam_attempt_history')
    .select('attempt_id, attempt_number, status, correct_count, score, passed, reactivation_reason, reactivated_by, archived_at')
    .in('attempt_id', attemptIds).order('attempt_number', { ascending: false });
  if (historyError) throw historyError;
  const emailById = new Map((students || []).map((student) => [student.id, student.email]));
  const historyByAttempt = new Map();
  for (const item of history || []) {
    const items = historyByAttempt.get(item.attempt_id) || [];
    items.push(item);
    historyByAttempt.set(item.attempt_id, items);
  }
  return attempts.map((attempt) => ({
    ...attempt,
    student_email: emailById.get(attempt.student_id),
    history: historyByAttempt.get(attempt.id) || [],
  }));
}

async function reactivate(studentId, reason, evaluatorEmail, questionOrder) {
  const { data, error } = await supabase.rpc('reactivate_exam_attempt', {
    p_student_id: studentId,
    p_reason: reason,
    p_evaluator_email: evaluatorEmail,
    p_question_order: questionOrder,
  });
  if (error) throw error;
  return data;
}

module.exports = { findByStudentId, create, saveAnswer, finish, listAllWithStudents, reactivate };
