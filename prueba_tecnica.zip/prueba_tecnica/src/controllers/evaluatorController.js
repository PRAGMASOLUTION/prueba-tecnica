const attemptModel = require('../models/attemptModel');
const questionModel = require('../models/questionModel');
const { createSessionCookie, clearSessionCookie } = require('../config/session');

function login(req, res) {
  const expectedEmail = (process.env.EVALUATOR_EMAIL || '').trim().toLowerCase();
  const expected = process.env.EVALUATOR_PASSWORD;
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  if (!expectedEmail || !expected || expected.startsWith('cambia_') || email !== expectedEmail || password !== expected) {
    return res.status(401).json({ error: 'El correo maestro o la contraseña no son correctos.' });
  }
  createSessionCookie(res, { role: 'evaluator', email });
  return res.json({ authenticated: true });
}

async function getAttempts(_req, res, next) {
  try {
    const [attempts, questions] = await Promise.all([attemptModel.listAllWithStudents(), questionModel.listActiveQuestions()]);
    const byId = new Map(questions.map((question) => [question.id, question]));
    res.json({ attempts: attempts.map((attempt) => ({
      studentId: attempt.student_id,
      email: attempt.student_email,
      status: attempt.status,
      score: attempt.score,
      correctCount: attempt.correct_count,
      passed: attempt.passed,
      attemptNumber: attempt.attempt_number,
      startedAt: attempt.started_at,
      finishedAt: attempt.submitted_at || attempt.locked_at,
      history: attempt.history.map((item) => ({
        attemptNumber: item.attempt_number,
        status: item.status,
        correctCount: item.correct_count,
        score: item.score,
        passed: item.passed,
        reason: item.reactivation_reason,
        reactivatedBy: item.reactivated_by,
        archivedAt: item.archived_at,
      })),
      answers: (attempt.question_order || []).map((questionId) => {
        const question = byId.get(questionId);
        const selected = attempt.answers?.[String(questionId)] || null;
        return { questionText: question?.question_text || 'Pregunta no disponible', selected, correctOption: question?.correct_option || null, isCorrect: Boolean(question && selected === question.correct_option) };
      }),
    })) });
  } catch (error) { next(error); }
}

async function reactivate(req, res, next) {
  try {
    const studentId = req.params.studentId;
    const reason = typeof req.body.reason === 'string' ? req.body.reason.trim() : '';
    if (reason.length < 10 || reason.length > 500) {
      return res.status(400).json({ error: 'Escribe un motivo de entre 10 y 500 caracteres.' });
    }
    const attempt = await attemptModel.findByStudentId(studentId);
    if (!attempt) return res.status(404).json({ error: 'No se encontró el intento de ese estudiante.' });
    if (attempt.status === 'in_progress') return res.status(409).json({ error: 'El estudiante ya tiene un intento activo.' });
    const questions = await questionModel.listActiveQuestions();
    if (questions.length !== 5) return res.status(503).json({ error: 'El examen debe tener cinco preguntas activas.' });
    const order = [...questions.map((question) => question.id)];
    for (let index = order.length - 1; index > 0; index -= 1) {
      const other = require('node:crypto').randomInt(index + 1);
      [order[index], order[other]] = [order[other], order[index]];
    }
    await attemptModel.reactivate(studentId, reason, req.session.email, order);
    return res.json({ reactivated: true });
  } catch (error) { return next(error); }
}

function logout(_req, res) { clearSessionCookie(res); res.status(204).end(); }
module.exports = { login, getAttempts, reactivate, logout };
