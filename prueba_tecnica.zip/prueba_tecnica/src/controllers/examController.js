const crypto = require('node:crypto');
const studentModel = require('../models/studentModel');
const attemptModel = require('../models/attemptModel');
const questionModel = require('../models/questionModel');
const { createSessionCookie, clearSessionCookie } = require('../config/session');

function shuffle(values) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = crypto.randomInt(index + 1);
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

function resultFor(attempt, questions) {
  const byId = new Map(questions.map((question) => [question.id, question]));
  const results = (attempt.question_order || []).map((id) => {
    const question = byId.get(id);
    const selected = attempt.answers?.[String(id)] || null;
    return {
      id,
      questionText: question?.question_text || 'Pregunta no disponible',
      options: question?.options || {},
      selected,
      correctOption: question?.correct_option || null,
      isCorrect: Boolean(question && selected === question.correct_option),
    };
  });
  const correctCount = results.filter((item) => item.isCorrect).length;
  const score = correctCount * 2;
  return { results, correctCount, score, passed: score >= 6 };
}

function visibleQuestion(question) {
  return { id: question.id, questionText: question.question_text, options: question.options };
}

async function getOrCreateAttempt(studentId) {
  const existing = await attemptModel.findByStudentId(studentId);
  if (existing) return existing;
  const questions = await questionModel.listActiveQuestions();
  if (questions.length !== 5) {
    const error = new Error('El examen debe tener exactamente cinco preguntas activas.');
    error.status = 503;
    throw error;
  }
  return attemptModel.create(studentId, shuffle(questions.map((question) => question.id)));
}

async function login(req, res, next) {
  try {
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    if (!email.includes('@') || /\s/.test(email)) return res.status(400).json({ error: 'Escribe un correo que incluya @ y no tenga espacios.' });
    const student = await studentModel.findOrCreateByEmail(email);
    const attempt = await getOrCreateAttempt(student.id);
    createSessionCookie(res, { role: 'student', studentId: student.id, email: student.email });
    res.json({ email: student.email, status: attempt.status });
  } catch (error) { next(error); }
}

async function getExam(req, res, next) {
  try {
    const attempt = await getOrCreateAttempt(req.session.studentId);
    const questions = await questionModel.listActiveQuestions();
    if (attempt.status === 'in_progress') {
      return res.json({
        status: attempt.status,
        email: req.session.email,
        questions: attempt.question_order.map((id) => questions.find((q) => q.id === id)).filter(Boolean).map(visibleQuestion),
        answers: attempt.answers || {},
      });
    }
    const result = resultFor(attempt, questions);
    return res.json({
      status: attempt.status,
      email: req.session.email,
      score: attempt.score ?? result.score,
      correctCount: attempt.correct_count ?? result.correctCount,
      passed: attempt.passed ?? result.passed,
      total: result.results.length,
      attemptNumber: attempt.attempt_number || 1,
      results: result.results,
      lockedAt: attempt.locked_at,
      submittedAt: attempt.submitted_at,
    });
  } catch (error) { next(error); }
}

async function saveAnswer(req, res, next) {
  try {
    const questionId = Number(req.body.questionId);
    const choice = typeof req.body.choice === 'string' ? req.body.choice.toUpperCase() : '';
    const attempt = await attemptModel.findByStudentId(req.session.studentId);
    if (!attempt || attempt.status !== 'in_progress') return res.status(409).json({ error: 'Este intento ya no acepta respuestas.' });
    if (!attempt.question_order.includes(questionId)) return res.status(400).json({ error: 'La pregunta no pertenece a este examen.' });
    const question = (await questionModel.listActiveQuestions()).find((item) => item.id === questionId);
    if (!question || !Object.hasOwn(question.options, choice)) return res.status(400).json({ error: 'Selecciona una de las opciones disponibles.' });
    const answers = { ...(attempt.answers || {}), [String(questionId)]: choice };
    const updated = await attemptModel.saveAnswer(attempt.id, answers);
    if (!updated) return res.status(409).json({ error: 'El intento ya fue cerrado.' });
    res.json({ saved: true });
  } catch (error) { next(error); }
}

async function closeAttempt(req, res, next, status) {
  try {
    const attempt = await attemptModel.findByStudentId(req.session.studentId);
    if (!attempt) return res.status(404).json({ error: 'No se encontró el intento.' });
    if (attempt.status !== 'in_progress') return getExam(req, res, next);
    const questions = await questionModel.listActiveQuestions();
    const result = resultFor(attempt, questions);
    await attemptModel.finish(attempt.id, status, result.correctCount, result.score, result.passed);
    return getExam(req, res, next);
  } catch (error) { next(error); }
}

function submit(req, res, next) { return closeAttempt(req, res, next, 'submitted'); }
function lock(req, res, next) { return closeAttempt(req, res, next, 'locked'); }
function logout(_req, res) { clearSessionCookie(res); res.status(204).end(); }

module.exports = { login, getExam, saveAnswer, submit, lock, logout };
