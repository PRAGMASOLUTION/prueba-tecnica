const attemptModel = require('../models/attemptModel');

async function getResults(_req, res, next) {
  try {
    const attempts = await attemptModel.listAllWithStudents();
    return res.json({ results: attempts.map((attempt) => ({
      email: attempt.student_email,
      status: attempt.status,
      attemptNumber: attempt.attempt_number,
      correctCount: attempt.correct_count,
      score: attempt.score,
      passed: attempt.passed,
      finishedAt: attempt.submitted_at || attempt.locked_at,
    })) });
  } catch (error) { return next(error); }
}

module.exports = { getResults };
