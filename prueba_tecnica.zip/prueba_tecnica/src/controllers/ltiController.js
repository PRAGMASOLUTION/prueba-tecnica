const crypto = require('node:crypto');
const supabase = require('../config/supabase');
const studentModel = require('../models/studentModel');
const attemptModel = require('../models/attemptModel');
const questionModel = require('../models/questionModel');
const { createSessionCookie } = require('../config/session');

function encode(value) {
  return encodeURIComponent(String(value)).replace(/[!*'()]/g, (character) => `%${character.charCodeAt(0).toString(16).toUpperCase()}`);
}

function checkSignature(req) {
  const consumerKey = process.env.LTI_CONSUMER_KEY;
  const consumerSecret = process.env.LTI_CONSUMER_SECRET;
  if (!consumerKey || !consumerSecret) {
    const error = new Error('La integración LTI todavía no está configurada.');
    error.status = 503;
    throw error;
  }
  const body = req.body || {};
  if (body.oauth_consumer_key !== consumerKey || body.oauth_signature_method !== 'HMAC-SHA1') return false;
  const timestamp = Number(body.oauth_timestamp);
  if (!Number.isFinite(timestamp) || Math.abs(Date.now() / 1000 - timestamp) > 300 || !body.oauth_nonce) return false;

  const launchUrl = process.env.LTI_PUBLIC_URL;
  const url = launchUrl
    ? new URL(launchUrl)
    : new URL(req.originalUrl, `${req.protocol}://${req.get('host')}`);
  const baseUrl = `${url.protocol}//${url.host}${url.pathname}`;
  const parameters = [];
  for (const [key, value] of url.searchParams.entries()) parameters.push([key, value]);
  for (const [key, value] of Object.entries(body)) {
    if (key === 'oauth_signature') continue;
    if (Array.isArray(value) || (value !== null && typeof value === 'object')) return false;
    parameters.push([key, String(value)]);
  }
  const encoded = parameters.map(([key, value]) => [encode(key), encode(value)])
    .sort((a, b) => a[0] === b[0] ? (a[1] < b[1] ? -1 : a[1] > b[1] ? 1 : 0) : (a[0] < b[0] ? -1 : 1))
    .map(([key, value]) => `${key}=${value}`).join('&');
  const baseString = `${req.method.toUpperCase()}&${encode(baseUrl)}&${encode(encoded)}`;
  const expected = crypto.createHmac('sha1', `${encode(consumerSecret)}&`).update(baseString).digest('base64');
  const givenBuffer = Buffer.from(String(body.oauth_signature || ''));
  const expectedBuffer = Buffer.from(expected);
  return givenBuffer.length === expectedBuffer.length && crypto.timingSafeEqual(givenBuffer, expectedBuffer);
}

async function recordNonce(consumerKey, nonce) {
  await supabase.from('lti_launch_nonces').delete().lt('created_at', new Date(Date.now() - 86400000).toISOString());
  const { error } = await supabase.from('lti_launch_nonces').insert({ nonce: `${consumerKey}:${nonce}` });
  if (error?.code === '23505') return false;
  if (error) throw error;
  return true;
}

function shuffle(values) {
  const result = [...values];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = crypto.randomInt(i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

async function launch(req, res, next) {
  try {
    const body = req.body || {};
    if (!checkSignature(req)) return res.status(401).send('Lanzamiento LTI no válido.');
    if (body.lti_message_type !== 'basic-lti-launch-request' || !body.user_id) return res.status(400).send('Solicitud LTI incompleta.');
    if (!await recordNonce(body.oauth_consumer_key, body.oauth_nonce)) return res.status(401).send('El lanzamiento LTI ya fue utilizado.');

    const ltiUserId = `${body.oauth_consumer_key}:${body.user_id}`;
    const submittedEmail = typeof body.lis_person_contact_email_primary === 'string' ? body.lis_person_contact_email_primary.trim().toLowerCase() : '';
    const email = submittedEmail.includes('@') && !/\s/.test(submittedEmail)
      ? submittedEmail
      : `lti-${crypto.createHash('sha256').update(ltiUserId).digest('hex').slice(0, 20)}@lti.demo`;
    const student = await studentModel.findOrCreateByLti(ltiUserId, email);
    let attempt = await attemptModel.findByStudentId(student.id);
    if (!attempt) {
      const questions = await questionModel.listActiveQuestions();
      if (questions.length !== 5) return res.status(503).send('El examen no está configurado.');
      attempt = await attemptModel.create(student.id, shuffle(questions.map((question) => question.id)));
    }
    createSessionCookie(res, { role: 'student', studentId: student.id, email: student.email, lti: true });
    return res.redirect(303, '/');
  } catch (error) { return next(error); }
}

module.exports = { launch };
