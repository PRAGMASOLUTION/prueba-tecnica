const express = require('express');
const controller = require('../controllers/sharedResultsController');

const router = express.Router();
router.get('/', controller.getResults);
module.exports = router;
