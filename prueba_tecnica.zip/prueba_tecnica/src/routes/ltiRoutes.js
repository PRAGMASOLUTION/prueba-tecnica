const express = require('express');
const controller = require('../controllers/ltiController');

const router = express.Router();
router.post('/launch', controller.launch);
module.exports = router;
