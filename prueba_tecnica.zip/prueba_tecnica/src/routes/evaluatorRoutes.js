const express = require('express');
const controller = require('../controllers/evaluatorController');
const { requireEvaluator } = require('../middleware/sessionMiddleware');

const router = express.Router();
router.post('/login', controller.login);
router.get('/attempts', requireEvaluator, controller.getAttempts);
router.post('/attempts/:studentId/reactivate', requireEvaluator, controller.reactivate);
router.post('/logout', requireEvaluator, controller.logout);
module.exports = router;
