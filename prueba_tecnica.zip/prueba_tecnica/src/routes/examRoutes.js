const express = require('express');
const controller = require('../controllers/examController');
const { requireStudent } = require('../middleware/sessionMiddleware');

const router = express.Router();
router.post('/session', controller.login);
router.get('/exam', requireStudent, controller.getExam);
router.post('/answers', requireStudent, controller.saveAnswer);
router.post('/submit', requireStudent, controller.submit);
router.post('/lock', requireStudent, controller.lock);
router.post('/logout', controller.logout);
module.exports = router;
