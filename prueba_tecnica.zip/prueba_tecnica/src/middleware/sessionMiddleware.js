const { readSession } = require('../config/session');

function requireStudent(req, res, next) {
  const session = readSession(req);
  if (!session || !session.studentId || session.role !== 'student') return res.status(401).json({ error: 'Ingresa tu correo para continuar.' });
  req.session = session;
  next();
}

function requireEvaluator(req, res, next) {
  const session = readSession(req);
  if (!session || session.role !== 'evaluator') return res.status(401).json({ error: 'Inicia sesión como evaluador.' });
  req.session = session;
  next();
}

module.exports = { requireStudent, requireEvaluator };
