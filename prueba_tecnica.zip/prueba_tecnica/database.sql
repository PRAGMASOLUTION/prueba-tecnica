-- Base de datos de la demo de examen. Ejecutar desde Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.students (
    id uuid primary key default gen_random_uuid(),
    email text not null,
    created_at timestamptz not null default now(),
    constraint students_email_has_at check (position('@' in email) > 1 and position(' ' in email) = 0)
);
create unique index if not exists students_email_unique_idx on public.students (lower(email));

-- Identidad opcional para lanzamientos LTI desde Moodle.
alter table public.students add column if not exists lti_user_id text;
create unique index if not exists students_lti_user_unique_idx on public.students (lti_user_id) where lti_user_id is not null;

create table if not exists public.exam_questions (
    id smallint primary key,
    question_text text not null,
    options jsonb not null,
    correct_option char(1) not null check (correct_option in ('A', 'B', 'C', 'D')),
    active boolean not null default true,
    constraint exam_questions_options_are_object check (jsonb_typeof(options) = 'object'),
    constraint exam_questions_correct_option_exists check (options ? correct_option)
);
create table if not exists public.exam_attempts (
    id uuid primary key default gen_random_uuid(),
    student_id uuid not null unique references public.students(id) on delete restrict,
    status text not null default 'in_progress' check (status in ('in_progress', 'submitted', 'locked')),
    question_order smallint[] not null,
    answers jsonb not null default '{}'::jsonb,
    score smallint check (score is null or score between 0 and 5),
    started_at timestamptz not null default now(),
    submitted_at timestamptz,
    locked_at timestamptz,
    created_at timestamptz not null default now(),
    constraint exam_attempts_five_questions check (cardinality(question_order) = 5),
    constraint exam_attempts_answers_object check (jsonb_typeof(answers) = 'object')
);
create index if not exists exam_attempts_created_at_idx on public.exam_attempts (created_at desc);

create table if not exists public.lti_launch_nonces (
    nonce text primary key,
    created_at timestamptz not null default now()
);

insert into public.exam_questions (id, question_text, options, correct_option) values
    (1, 'El saldo inicial de Bancos es de $850,000.', '{"A":"Cargo","B":"Abono","C":"No se registra","D":"Se registra en ambas columnas"}', 'A'),
    (2, 'Se pagó al proveedor INMOBILIARIA SA la cantidad de $17,700.', '{"A":"Cargo","B":"Abono","C":"No se registra","D":"Se registra en ambas columnas"}', 'B'),
    (3, 'Se vendió una máquina envasadora y se cobró la cantidad de $120,000.', '{"A":"Cargo","B":"Abono","C":"No se registra","D":"Se registra en ambas columnas"}', 'A'),
    (4, 'Se entregaron viáticos por viaje a Monterrey al vendedor Javier Barrera por $70,000.', '{"A":"Cargo","B":"Abono","C":"No se registra","D":"Se registra en ambas columnas"}', 'B'),
    (5, 'El cliente ZAZA SA pagó por un servicio la cantidad de $25,000.', '{"A":"Cargo","B":"Abono","C":"No se registra","D":"Se registra en ambas columnas"}', 'A')
on conflict (id) do update set question_text = excluded.question_text, options = excluded.options, correct_option = excluded.correct_option, active = true;

insert into public.students (email) values ('ana.demo@example.com'), ('luis.demo@example.com'), ('maria.demo@example.com') on conflict do nothing;

alter table public.students enable row level security;
alter table public.exam_questions enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.lti_launch_nonces enable row level security;

grant usage on schema public to service_role;
revoke all on public.students, public.exam_questions, public.exam_attempts, public.lti_launch_nonces from anon, authenticated;
grant select, insert, update, delete on public.students, public.exam_questions, public.exam_attempts, public.lti_launch_nonces to service_role;

-- Cambios de calificación y reactivación con historial.
alter table public.exam_attempts add column if not exists correct_count smallint;
alter table public.exam_attempts add column if not exists passed boolean;
alter table public.exam_attempts add column if not exists attempt_number integer not null default 1;
alter table public.exam_attempts drop constraint if exists exam_attempts_score_check;
alter table public.exam_attempts drop constraint if exists exam_attempts_score_valid;

do $$ begin
    if not exists (select 1 from pg_constraint where conname = 'exam_attempts_score_0_10') then
        alter table public.exam_attempts add constraint exam_attempts_score_0_10 check (score is null or score between 0 and 10);
    end if;
    if not exists (select 1 from pg_constraint where conname = 'exam_attempts_correct_count_0_5') then
        alter table public.exam_attempts add constraint exam_attempts_correct_count_0_5 check (correct_count is null or correct_count between 0 and 5);
    end if;
end $$;

-- Convierte resultados guardados antes de usar la escala de 10 puntos.
update public.exam_attempts
set correct_count = score,
    passed = (score >= 3),
    score = score * 2
where score is not null and correct_count is null;

create table if not exists public.exam_attempt_history (
    attempt_id uuid not null references public.exam_attempts(id) on delete cascade,
    student_id uuid not null references public.students(id) on delete restrict,
    attempt_number integer not null,
    status text not null,
    question_order smallint[] not null,
    answers jsonb not null,
    correct_count smallint,
    score smallint,
    passed boolean,
    started_at timestamptz not null,
    submitted_at timestamptz,
    locked_at timestamptz,
    reactivation_reason text not null,
    reactivated_by text not null,
    archived_at timestamptz not null default now(),
    primary key (attempt_id, attempt_number)
);
alter table public.exam_attempt_history enable row level security;

create or replace function public.reactivate_exam_attempt(
    p_student_id uuid,
    p_reason text,
    p_evaluator_email text,
    p_question_order smallint[]
) returns public.exam_attempts
language plpgsql security definer set search_path = public
as $$
declare
    previous_attempt public.exam_attempts%rowtype;
    new_attempt public.exam_attempts%rowtype;
begin
    if length(trim(p_reason)) < 10 or length(trim(p_reason)) > 500 then
        raise exception 'El motivo debe tener entre 10 y 500 caracteres';
    end if;
    if cardinality(p_question_order) <> 5 then
        raise exception 'El examen debe incluir cinco preguntas';
    end if;

    select * into previous_attempt
    from public.exam_attempts
    where student_id = p_student_id
    for update;

    if not found then raise exception 'No se encontró el intento'; end if;
    if previous_attempt.status = 'in_progress' then raise exception 'El intento todavía está activo'; end if;

    insert into public.exam_attempt_history (
        attempt_id, student_id, attempt_number, status, question_order, answers,
        correct_count, score, passed, started_at, submitted_at, locked_at,
        reactivation_reason, reactivated_by
    ) values (
        previous_attempt.id, previous_attempt.student_id, previous_attempt.attempt_number,
        previous_attempt.status, previous_attempt.question_order, previous_attempt.answers,
        previous_attempt.correct_count, previous_attempt.score, previous_attempt.passed,
        previous_attempt.started_at, previous_attempt.submitted_at, previous_attempt.locked_at,
        trim(p_reason), p_evaluator_email
    );

    update public.exam_attempts
    set status = 'in_progress',
        attempt_number = previous_attempt.attempt_number + 1,
        question_order = p_question_order,
        answers = '{}'::jsonb,
        correct_count = null,
        score = null,
        passed = null,
        started_at = now(),
        submitted_at = null,
        locked_at = null
    where id = previous_attempt.id
    returning * into new_attempt;

    return new_attempt;
end;
$$;

revoke all on function public.reactivate_exam_attempt(uuid, text, text, smallint[]) from public, anon, authenticated;
grant execute on function public.reactivate_exam_attempt(uuid, text, text, smallint[]) to service_role;
revoke all on public.exam_attempt_history from anon, authenticated;
grant select, insert, update, delete on public.exam_attempt_history to service_role;

-- Ajustes para proyectos que ejecutaron una versión anterior del esquema.
alter table public.students drop constraint if exists students_email_format;
alter table public.students drop constraint if exists students_email_has_at;
alter table public.students add constraint students_email_has_at check (position('@' in email) > 1 and position(' ' in email) = 0);
alter table public.exam_attempts alter column question_order type smallint[] using question_order::smallint[];
