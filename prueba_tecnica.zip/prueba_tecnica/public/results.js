const message = document.querySelector('#results-message');
const table = document.querySelector('#results-table');

async function loadResults() {
  message.textContent = 'Cargando resultados…';
  try {
    const response = await fetch('/api/shared-results');
    const body = await response.json();
    if (!response.ok) throw new Error(body?.error || 'No se pudieron cargar los resultados.');
    message.textContent = '';
    showResults(body.results);
  } catch (error) {
    message.textContent = error.message;
  }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}

function formatDate(value) {
  return value ? new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
}

function showResults(results) {
  if (!results.length) {
    table.innerHTML = '<div class="panel empty-state">Todavía no hay resultados registrados.</div>';
    return;
  }
  table.innerHTML = `<div class="table-wrap"><table class="results-table"><thead><tr><th>Correo</th><th>Intento</th><th>Aciertos</th><th>Calificación</th><th>Resultado</th><th>Estado</th><th>Fecha</th></tr></thead><tbody>
    ${results.map((result) => `<tr>
      <td>${escapeHtml(result.email)}</td><td>${result.attemptNumber ?? 1}</td>
      <td>${result.correctCount ?? '—'}/5</td><td>${result.score === null ? '—' : `${result.score}/10`}</td>
      <td>${result.passed === null ? 'Pendiente' : result.passed ? 'Aprobado' : 'Reprobado'}</td>
      <td>${result.status === 'locked' ? 'Bloqueado' : result.status === 'submitted' ? 'Entregado' : 'En curso'}</td>
      <td>${formatDate(result.finishedAt)}</td>
    </tr>`).join('')}
  </tbody></table></div>`;
}

document.querySelector('#refresh-results').addEventListener('click', loadResults);
loadResults();
