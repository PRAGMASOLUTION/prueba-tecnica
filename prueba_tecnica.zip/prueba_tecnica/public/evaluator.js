const loginPanel = document.querySelector('#evaluator-login');
const dashboard = document.querySelector('#evaluator-dashboard');
const message = document.querySelector('#evaluator-message');
const form = document.querySelector('#evaluator-form');
const tableContainer = document.querySelector('#attempts-table');

async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const body = response.status === 204 ? null : await response.json();
  if (!response.ok) throw new Error(body?.error || 'No se pudo completar la solicitud.');
  return body;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}

function formatDate(value) {
  return value ? new Intl.DateTimeFormat('es-MX', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : '—';
}

function renderAttempt(attempt) {
  const isActive = attempt.status === 'in_progress';
  const grade = attempt.score === null ? '—' : `${attempt.score}/10`;
  const passLabel = attempt.passed === null ? '' : `<span class="grade-status small ${attempt.passed ? 'passed' : 'failed'}">${attempt.passed ? 'APROBADO' : 'REPROBADO'}</span>`;
  const statusLabel = isActive ? 'En curso' : attempt.status === 'locked' ? 'Bloqueado' : 'Entregado';
  const answers = attempt.answers.map((answer, index) => `<div><strong>${index + 1}.</strong> ${escapeHtml(answer.selected ? `${answer.selected}${answer.isCorrect ? ' ✓' : ' · incorrecta'}` : 'Sin respuesta')}</div>`).join('');
  const history = attempt.history.length ? `<details class="history-details"><summary>Ver historial (${attempt.history.length})</summary>${attempt.history.map((item) => `<div class="history-item"><strong>Intento ${item.attemptNumber}:</strong> ${item.correctCount ?? 0}/5 aciertos · ${item.score ?? 0}/10 · ${item.passed ? 'Aprobado' : 'Reprobado'}<br><span>Motivo: ${escapeHtml(item.reason)}</span><br><span>Autorizó: ${escapeHtml(item.reactivatedBy)} · ${formatDate(item.archivedAt)}</span></div>`).join('')}</details>` : '';
  const action = isActive
    ? '<span class="muted">El intento está activo</span>'
    : `<button class="button button-reactivate" type="button" data-open-reactivation="${escapeHtml(attempt.studentId)}">Reactivar examen</button>
       <form class="reactivation-form hidden" data-reactivation-form="${escapeHtml(attempt.studentId)}">
         <label for="reason-${escapeHtml(attempt.studentId)}">Motivo de la reactivación</label>
         <textarea id="reason-${escapeHtml(attempt.studentId)}" name="reason" minlength="10" maxlength="500" required placeholder="Explica por qué se autoriza un nuevo intento"></textarea>
         <div class="reactivation-actions"><button class="button button-primary" type="submit">Confirmar reactivación</button><button class="button button-cancel" type="button" data-cancel-reactivation="${escapeHtml(attempt.studentId)}">Cancelar</button></div>
         <div class="message" data-reactivation-message="${escapeHtml(attempt.studentId)}" role="status"></div>
       </form>`;

  return `<tr>
    <td><strong>${escapeHtml(attempt.email)}</strong><div class="table-subtext">Intento ${attempt.attemptNumber}</div></td>
    <td><span class="status-tag ${attempt.status === 'locked' ? 'locked' : ''}">${statusLabel}</span></td>
    <td><strong>${grade}</strong><div class="table-subtext">${attempt.correctCount ?? 0}/5 aciertos ${passLabel}</div></td>
    <td>${formatDate(attempt.finishedAt || attempt.startedAt)}</td>
    <td><div class="result-details">${answers}${history}</div></td>
    <td><div class="action-cell">${action}</div></td>
  </tr>`;
}

function showDashboard(attempts) {
  loginPanel.classList.add('hidden');
  dashboard.classList.remove('hidden');
  if (!attempts.length) {
    tableContainer.innerHTML = '<div class="panel empty-state">Todavía no hay intentos registrados.</div>';
    return;
  }
  tableContainer.innerHTML = `<div class="table-wrap"><table class="results-table">
    <thead><tr><th>Estudiante</th><th>Estado</th><th>Calificación</th><th>Fecha</th><th>Respuestas e historial</th><th>Acción</th></tr></thead>
    <tbody>${attempts.map(renderAttempt).join('')}</tbody></table></div>`;
}

async function loadAttempts() { showDashboard((await api('/api/evaluator/attempts')).attempts); }

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  message.textContent = '';
  const button = form.querySelector('button');
  button.disabled = true;
  try {
    await api('/api/evaluator/login', {
      method: 'POST',
      body: JSON.stringify({
        email: document.querySelector('#evaluator-email').value,
        password: document.querySelector('#evaluator-password').value,
      }),
    });
    await loadAttempts();
  } catch (error) { message.textContent = error.message; }
  finally { button.disabled = false; }
});

tableContainer.addEventListener('click', async (event) => {
  const openButton = event.target.closest('[data-open-reactivation]');
  if (openButton) {
    const formToShow = tableContainer.querySelector(`[data-reactivation-form="${CSS.escape(openButton.dataset.openReactivation)}"]`);
    formToShow?.classList.remove('hidden');
    openButton.classList.add('hidden');
  }
  const cancelButton = event.target.closest('[data-cancel-reactivation]');
  if (cancelButton) {
    const id = CSS.escape(cancelButton.dataset.cancelReactivation);
    tableContainer.querySelector(`[data-reactivation-form="${id}"]`)?.classList.add('hidden');
    tableContainer.querySelector(`[data-open-reactivation="${id}"]`)?.classList.remove('hidden');
  }
});

tableContainer.addEventListener('submit', async (event) => {
  const reactivationForm = event.target.closest('[data-reactivation-form]');
  if (!reactivationForm) return;
  event.preventDefault();
  const studentId = reactivationForm.dataset.reactivationForm;
  const reason = new FormData(reactivationForm).get('reason').trim();
  const status = tableContainer.querySelector(`[data-reactivation-message="${CSS.escape(studentId)}"]`);
  const button = reactivationForm.querySelector('button[type="submit"]');
  if (reason.length < 10) { status.textContent = 'Escribe un motivo de al menos 10 caracteres.'; return; }
  button.disabled = true;
  status.textContent = 'Guardando autorización…';
  try {
    await api(`/api/evaluator/attempts/${encodeURIComponent(studentId)}/reactivate`, { method: 'POST', body: JSON.stringify({ reason }) });
    await loadAttempts();
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
});

document.querySelector('#evaluator-logout').addEventListener('click', async () => {
  await api('/api/evaluator/logout', { method: 'POST', body: '{}' });
  window.location.reload();
});

loadAttempts().catch(() => {});
