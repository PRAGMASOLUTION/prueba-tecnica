const loginScreen = document.querySelector('#login-screen');
const examScreen = document.querySelector('#exam-screen');
const resultScreen = document.querySelector('#result-screen');
const loginForm = document.querySelector('#login-form');
const examForm = document.querySelector('#exam-form');
const loginMessage = document.querySelector('#login-message');
const examMessage = document.querySelector('#exam-message');
const saveStatus = document.querySelector('#save-status');
let currentQuestions = [];
let currentAnswers = {};
let examIsActive = false;
let lockRequestSent = false;
let pendingAnswerSave = Promise.resolve();

async function request(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const body = response.status === 204 ? null : await response.json();
  if (!response.ok) throw new Error(body?.error || 'No se pudo completar la solicitud.');
  return body;
}

function showScreen(screen) {
  [loginScreen, examScreen, resultScreen].forEach((item) => item.classList.add('hidden'));
  screen.classList.remove('hidden');
}

function setExamActive(active) {
  examIsActive = active;
  if (active) document.addEventListener('visibilitychange', handleVisibilityChange);
  else document.removeEventListener('visibilitychange', handleVisibilityChange);
}

async function handleVisibilityChange() {
  if (!document.hidden || !examIsActive || lockRequestSent) return;
  lockRequestSent = true;
  setExamActive(false);
  saveStatus.textContent = 'El intento se está bloqueando…';
  try {
    await pendingAnswerSave;
    renderResult(await request('/api/lock', { method: 'POST', body: '{}' }));
  } catch (error) {
    examMessage.textContent = `No fue posible guardar el bloqueo: ${error.message}`;
  }
}

async function loadExam() {
  const state = await request('/api/exam');
  if (state.status === 'in_progress') renderExam(state);
  else renderResult(state);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}

function renderExam(state) {
  currentQuestions = state.questions;
  currentAnswers = state.answers || {};
  document.querySelector('#student-email').textContent = state.email;
  examForm.innerHTML = currentQuestions.map((question, index) => `
    <article class="panel question-card">
      <div class="question-title"><span class="question-number">${index + 1}</span><span>${escapeHtml(question.questionText)}</span></div>
      <div class="options" role="radiogroup" aria-label="Respuestas para la pregunta ${index + 1}">
        ${Object.entries(question.options).map(([key, label]) => `
          <label class="option"><input type="radio" name="question-${question.id}" value="${escapeHtml(key)}" ${currentAnswers[String(question.id)] === key ? 'checked' : ''}><span><strong>${escapeHtml(key)})</strong> ${escapeHtml(label)}</span></label>
        `).join('')}
      </div>
    </article>`).join('');
  showScreen(examScreen);
  setExamActive(true);
}

function renderResult(state) {
  setExamActive(false);
  const locked = state.status === 'locked';
  resultScreen.innerHTML = `
    <div class="result-hero">
      <div class="result-icon">${locked ? '!' : '✓'}</div>
      <div class="eyebrow">${locked ? 'INTENTO BLOQUEADO' : 'EXAMEN FINALIZADO'}</div>
      <h1>${locked ? 'Tu examen quedó bloqueado' : 'Resultado del examen'}</h1>
      <p class="muted">${locked ? 'La página detectó que dejó de estar visible. Este intento no se puede reanudar.' : 'Este resultado queda guardado y el examen no se puede repetir.'}</p>
      <div class="score">${state.score}/10</div>
      <div class="grade-caption">Calificación · ${state.correctCount}/${state.total} aciertos · 2 puntos por acierto</div>
      <div class="grade-status ${state.passed ? 'passed' : 'failed'}">${state.passed ? 'APROBADO' : 'REPROBADO'}</div>
      <div class="result-status ${locked ? 'locked' : ''}">${locked ? 'Intento bloqueado' : `Intento ${state.attemptNumber || 1} · entregado`}</div>
    </div>
    <div class="result-list">${(state.results || []).map((item, index) => `
      <article class="panel result-card ${item.isCorrect ? 'correct' : 'incorrect'}">
        <h3>${index + 1}. ${escapeHtml(item.questionText)}</h3>
        <div class="result-line">Tu respuesta: <strong>${item.selected ? `${escapeHtml(item.selected)}) ${escapeHtml(item.options[item.selected] || '')}` : 'Sin respuesta'}</strong></div>
        <div class="result-line">Respuesta correcta: <strong>${item.correctOption ? `${escapeHtml(item.correctOption)}) ${escapeHtml(item.options[item.correctOption] || '')}` : 'No disponible'}</strong></div>
        <div class="result-mark">${item.isCorrect ? '✓ Correcta' : '× Incorrecta'}</div>
      </article>`).join('')}
    </div>
    <div class="result-actions"><button id="logout-button" class="button button-primary" type="button">Volver al inicio</button></div>`;
  showScreen(resultScreen);
  document.querySelector('#logout-button').addEventListener('click', async () => {
    await request('/api/logout', { method: 'POST', body: '{}' });
    window.location.reload();
  });
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  loginMessage.textContent = '';
  const button = loginForm.querySelector('button');
  button.disabled = true;
  try {
    await request('/api/session', { method: 'POST', body: JSON.stringify({ email: document.querySelector('#email').value }) });
    lockRequestSent = false;
    await loadExam();
  } catch (error) { loginMessage.textContent = error.message; }
  finally { button.disabled = false; }
});

examForm.addEventListener('change', async (event) => {
  if (!event.target.matches('input[type="radio"]')) return;
  const questionId = Number(event.target.name.replace('question-', ''));
  currentAnswers[String(questionId)] = event.target.value;
  saveStatus.textContent = 'Guardando respuesta…';
  const choice = event.target.value;
  pendingAnswerSave = pendingAnswerSave.then(() => request('/api/answers', {
    method: 'POST', body: JSON.stringify({ questionId, choice }),
  })).then(() => {
    saveStatus.textContent = 'Respuesta guardada automáticamente.';
  }).catch((error) => {
    saveStatus.textContent = error.message;
  });
});

examForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!window.confirm('¿Enviar el examen? Después de enviarlo no podrás cambiar tus respuestas.')) return;
  setExamActive(false);
  const button = document.querySelector('#submit-exam');
  button.disabled = true;
  try {
    await pendingAnswerSave;
    renderResult(await request('/api/submit', { method: 'POST', body: '{}' }));
  }
  catch (error) { examMessage.textContent = error.message; setExamActive(true); }
  finally { button.disabled = false; }
});

async function restoreSession() {
  try { lockRequestSent = false; await loadExam(); }
  catch { showScreen(loginScreen); }
}
restoreSession();
